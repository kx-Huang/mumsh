#ifndef DATA_H
#define DATA_H

#define BUFFER_SIZE 1024

extern int ctrl_c;
extern char cmd_buffer[BUFFER_SIZE];

#endif  // DATA_H
